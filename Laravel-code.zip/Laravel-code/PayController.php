<?php namespace App\Http\Controllers;

use App\Model\Order;
use App\Processor\Pay;
use App\Jobs\GenerateKey;
use Illuminate\Http\Request;
use App\Contracts\Listeners\Pay as Listener;
use Omnipay\Common\Message\AbstractResponse;

class PayController extends Controller implements Listener
{
    /**
     * Creating payment.
     *
     * @param  \App\Processor\Pay  $processor
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $order
     *
     * @return mixed
     */
    public function create(Pay $processor, Request $request, $order)
    {
        return $processor->create($this, $order, $request->all());
    }

    /**
     * Verify payment.
     *
     * @param  \App\Processor\Pay  $processor
     * @param  int  $order
     * @param  string  $gateway
     *
     * @return mixed
     */
    public function verify(Pay $processor, $order, $gateway)
    {
        return $processor->verify($this, $order, ['gateway' => $gateway]);
    }

    /**
     * Response when payment created.
     *
     * @param  \App\Model\Order  $order
     * @param  \Omnipay\Common\Message\AbstractResponse $response
     *
     * @return mixed
     */
    public function paymentCreated(Order $order, $gateway, AbstractResponse $response)
    {
        return redirect_with_message(handles('app::orders'), $response->getMessage());
    }

    /**
     * Response when payment require redirecting.
     *
     * @param  \App\Model\Order  $order
     * @param  \Omnipay\Common\Message\AbstractResponse $response
     *
     * @return void
     */
    public function paymentRedirected(Order $order, $gateway, AbstractResponse $response)
    {
        $response->redirect();
    }

    /**
     * Response when payment has failed.
     *
     * @param  \App\Model\Order  $order
     * @param  \Omnipay\Common\Message\AbstractResponse $response
     *
     * @return mixed
     */
    public function paymentFailed(Order $order, $gateway, AbstractResponse $response)
    {
        return redirect_with_message(handles('app::orders'), $response->getMessage(), 'error');
    }

    /**
     * Response when payment has failed validation.
     *
     * @param  \App\Model\Order  $order
     * @param  \Illuminate\Support\MessageBag|array  $errors
     *
     * @return mixed
     */
    public function paymentFailedValidation(Order $order, $errors)
    {
        return redirect_with_errors(handles("app::order-now/{$order->id}/pay"), $errors);
    }

    /**
     * Response when verification failed.
     *
     * @param  \App\Model\Order  $order
     * @param  string  $gateway
     *
     * @return mixed
     */
    public function verificationFailed(Order $order, $gateway)
    {
        return redirect(handles('app::orders'));
    }

    /**
     * Response when verification was successful.
     *
     * @param  \App\Model\Order  $order
     * @param  string  $gateway
     *
     * @return mixed
     */
    public function paymentVerified(Order $order, $gateway)
    {
        $this->dispatch(new GenerateKey($order));

        return redirect(handles('app::orders'));
    }
}
