<?php namespace App\Model;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

class Subscription extends Eloquent
{
    use SoftDeletes;

    const FULL_PACKAGE  = 'full';
    const TRIAL_PACKAGE = 'trial';

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'subscriptions';

    /**
     * Has many relationship with SubscriptionFile.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function files()
    {
        return $this->hasMany(SubscriptionFile::class, 'subscription_id');
    }

    /**
     * Has many relationship with SubscriptionPrice.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function prices()
    {
        return $this->hasMany(SubscriptionPrice::class, 'subscription_id');
    }

    /**
     * Has one relationship with SubscriptionPrice.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function price()
    {
        return $this->hasOne(SubscriptionPrice::class, 'subscription_id')
                ->where('currency', '=', config('payment.currency'));
    }

    /**
     * Active subscription scope.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     *
     * @return void
     */
    public function scopeActive(Builder $query)
    {
        $query->where('available', '=', 1);
    }

    /**
     * Active pricing scope.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     *
     * @return void
     */
    public function scopePricing(Builder $query)
    {
        return $query->with('price');
    }

    /**
     * Is subscription allowed for purchasing by user.
     *
     * @param  \App\Model\User|null  $user
     *
     * @return bool
     */
    public function isAllowedToPurchaseBy(User $user = null)
    {
        $available = $this->getAttribute('available');

        return (bool) $available;
    }
}
