<?php namespace App\Model;

use Carbon\Carbon;
use Orchestra\Model\User as Model;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class User extends Model implements AuthorizableContract
{
    use Authorizable;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The relations to eager load on every query.
     *
     * @var array
     */
    protected $with = ['profile'];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['subscription_ends_at'];

    /**
     * Has one relationship with Profile.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function profile()
    {
        return $this->hasOne(Profile::class, 'user_id');
    }

    /**
     * Attach profile to a user.
     *
     * @param  App\Model\Profile  $profile
     *
     * @return $this
     */
    public function addProfile(Profile $profile)
    {
        $this->profile()->save($profile);

        return $this;
    }

    /**
     * Has one relationship with Profile.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function l2tp()
    {
        return $this->hasOne(LayerTwoUser::class, 'user_id');
    }

    /**
     * Has many relationship with Order.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orders()
    {
        return $this->hasMany(Order::class, 'user_id');
    }

    /**
     * Determine if user has active subscription.
     *
     * @return bool
     */
    public function hasActiveSubscription()
    {
        $now = Carbon::now();

        $subscription = $this->getAttribute('subscription_ends_at');

        if (is_null($subscription)) {
            return false;
        }

        return $now->gt($subscription);
    }

    /**
     * Check if user has not make any order before.
     *
     * @return bool
     */
    public function isFirstTime()
    {
        return ($this->exists && $this->orders()->count() === 0);
    }
}
