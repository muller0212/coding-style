<?php namespace App\Http\Controllers;

use App\Model\Order;
use App\Model\Subscription;
use App\Processor\OrderNow;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Gate;
use App\Contracts\Listeners\OrderNow as Listener;

class OrderNowController extends Controller implements Listener
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => 'create']);
    }

    /**
     * Show available subscription.
     *
     * @param  \App\Processor\OrderNow  $processor
     *
     * @return mixed
     */
    public function create(OrderNow $processor)
    {
        return $processor->create($this);
    }

    /**
     * Store new subscription order.
     *
     * @param  \App\Processor\OrderNow  $processor
     * @param  \Illuminate\Http\Request  $request
     *
     * @return mixed
     */
    public function store(OrderNow $processor, Request $request)
    {
        return $processor->store($this, $request->all());
    }

    /**
     * Cancel an order.
     *
     * @param  \App\Processor\OrderNow  $processor
     * @param  int  $order
     *
     * @return mixed
     */
    public function cancel(OrderNow $processor, $order)
    {
        return $processor->cancel($this, $order);
    }

    /**
     * Select payment gateway.
     *
     * @param  int  $order
     *
     * @return mixed
     */
    public function gateway($order)
    {
        $order = Order::findOrFail($order);

        if (Gate::denies('pay', $order)) {
            abort(403);
        }

        $gateways = config('payment.drivers');

        return view('order-now.gateway', compact('order', 'gateways'));
    }

    /**
     * Continue with existing order.
     *
     * @param  \App\Model\Order  $order
     *
     * @return mixed
     */
    public function continueWithExistingOrder(Order $order)
    {
        return redirect(handles("app::order-now/{$order->id}/pay"));
    }

    /**
     * Response by showing available subscription.
     *
     * @param  \Illuminate\Database\Eloquent\Collection  $subscriptions
     *
     * @return mixed
     */
    public function showSubscription(Collection $subscriptions)
    {
        return view('order-now.start', compact('subscriptions'));
    }

    /**
     * Response when order has been created.
     *
     * @param  \App\Model\Order  $order
     *
     * @return mixed
     */
    public function orderCreated(Order $order)
    {
        return redirect(handles("app::order-now/{$order->id}/pay"));
    }

    /**
     * Response when order has been cancelled.
     *
     * @param  \App\Model\Order  $order
     *
     * @return mixed
     */
    public function orderCancelled(Order $order)
    {
        return redirect(handles('app::orders'));
    }
}
