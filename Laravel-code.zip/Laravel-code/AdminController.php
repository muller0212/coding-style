<?php

class AdminController extends BaseController {

	public function index()
	{
		View::share('user', Confide::user());
		return View::make('admin.index');
	}

	// Users
	// -------------------------------
	public function showUsers() {
		$users = User::all();
		return View::make('admin.users')
			->with('users', $users);
	}

	public function editUser($id) {
		$user = User::findOrFail($id);
		return View::make('admin.editUser')
			->with('user', $user);
	}

	public function deleteUser($id) {
		$user = User::findOrFail($id);
		$user->delete();
		Session::flash('flash', ['message' => 'Successfully deleted user!', 'type' => 'flash-success']);
		return Redirect::to('admin/users');
	}

	public function doEditUser($id) {
		$repo = App::make('UserRepository');
		$user = $repo->update($id, Input::all());
		$error = $user->errors()->all(':message');
		Session::flash('flash', ['message' => 'Successfully updated user.', 'type' => 'flash-success']);
    return Redirect::route('admin.editUser', array($id))
        ->withInput(Input::all())
        ->withErrors($error);
	}

	// Bios
	// -------------------------------

	public function showBios()
	{
		$bios = Bio::all();
		return View::make('admin.bios')
			->with('bios', $bios);
	}

	public function editBio($id)
	{
		$bio = Bio::findOrFail($id);
		return View::make('admin.editBio')
			->with('bio', $bio);
	}

  public function deleteBio($id) {
    $obj = Bio::findOrFail($id);
    $obj->delete();
    Session::flash('flash', ['message' => 'Successfully deleted bio!', 'type' => 'flash-success']);
    return Redirect::to('admin/bios');
  }

	public function doEditBio($id) {
		$rules = Bio::$rules;
		$allInput = Input::all();
		$validator = Validator::make($allInput, $rules);
		if ($validator->fails()) {
			$errors = $validator->errors();
			return Redirect::to('admin/bios/edit/' . $id)
				->withErrors($errors)
				->withInput();
		} else {
			$bio = Bio::findOrFail($id);
			$bio->fill(Input::all());
			$bio->save();
			Session::flash('flash', ['message' => 'Successfully updated bio.', 'type' => 'flash-success']);
			return Redirect::to('admin/bios/edit/' . $bio->id);
		}
	}

	public function newBio() {
		$bio = new Bio;
		return View::make('admin.editBio')
			->with('bio', $bio);
	}

	public function doNewBio() {
		$rules = Bio::$rules;
		$allInput = Input::all();
		$validator = Validator::make($allInput, $rules);
		if ($validator->fails()) {
			$errors = $validator->errors();
			return Redirect::route('admin.newBio')
				->withErrors($errors)
				->withInput();
		} else {
			$bio = Bio::create(Input::all());
			Session::flash('flash', ['message' => 'Successfully created bio.', 'type' => 'flash-success']);
			return Redirect::to('admin/bios/edit/' . $bio->id);
		}
	}

  // Medias
  // -------------------------------

  public function showMedias()
  {
    $medias = Media::all();
    return View::make('admin.medias')
      ->with('medias', $medias);
  }

  public function editMedia($id)
  {
    $media = Media::findOrFail($id);
    return View::make('admin.editMedia')
      ->with('media', $media);
  }

  public function deleteMedia($id) {
    $obj = Media::findOrFail($id);
    $obj->delete();
    Session::flash('flash', ['message' => 'Successfully deleted post!', 'type' => 'flash-success']);
    return Redirect::to('admin/medias');
  }

  public function doEditMedia($id) {
    $rules = Media::$rules;
    $allInput = Input::all();
    $validator = Validator::make($allInput, $rules);
    if ($validator->fails()) {
      $errors = $validator->errors();
      return Redirect::to('admin/medias/edit/' . $id)
        ->withErrors($errors)
        ->withInput();
    } else {
      $media = Media::findOrFail($id);
      $media->fill(Input::all());
      $media->save();
      Session::flash('flash', ['message' => 'Successfully updated media.', 'type' => 'flash-success']);
      return Redirect::to('admin/medias/edit/' . $media->id);
    }
  }

  public function newMedia() {
    $media = new Media;
    return View::make('admin.editMedia')
      ->with('media', $media);
  }

  public function doNewMedia() {
    $rules = Media::$rules;
    $allInput = Input::all();
    $validator = Validator::make($allInput, $rules);
    if ($validator->fails()) {
      $errors = $validator->errors();
      return Redirect::route('admin.newMedia')
        ->withErrors($errors)
        ->withInput();
    } else {
      $media = Media::create(Input::all());
      Session::flash('flash', ['message' => 'Successfully created media.', 'type' => 'flash-success']);
      return Redirect::to('admin/medias/edit/' . $media->id);
    }
  }

	// Projects
  // -------------------------------

  public function showProjects()
  {
    $projects = Project::all();
    return View::make('admin.projects')
      ->with('projects', $projects);
  }
	public function showEntry()
	{
		$entrys = ProjectEntry::getdata();
		return View::make('admin.entry')
			->with('entrys', $entrys);
	}


	public function editProject($id)
  {
    $project = Project::findOrFail($id);
    return View::make('admin.editProject')
      ->with('project', $project);
  }

  public function deleteProject($id) {
    $obj = Project::findOrFail($id);
    foreach ($obj->images as $pi) {
      $pi->delete();
    }
    $obj->delete();
    Session::flash('flash', ['message' => 'Successfully deleted project!', 'type' => 'flash-success']);
    return Redirect::to('admin/projects');
  }

  public function uploadProjectImage($id, $type) {
  	$input = Input::all();
  	$photos = $input['photos'];
  	$project = Project::findOrFail($id);
  	$imageFilenameIds = array();

   	foreach ($photos as $key => $photo) {
   		$filename = $photo->getClientOriginalName();
    	$pi = new ProjectImage;
    	$pi->type = $type;
    	$pi->image = $photo;
    	$project->images()->save($pi);
    	$imageFilenameIds[$filename] = $pi->id;
    }
    $resp = array('status' => 'success', 'ids' => $imageFilenameIds);
    return Response::json($resp, 200);
  }

  public function deleteProjectImage($id) {
  	$pi = ProjectImage::findOrFail($id);
  	$pi->delete();
    return Response::json('deleted photo ' . $id, 200);
  }

  public function doEditProject($id) {
    $rules = Project::$rules;
    $allInput = Input::all();
    $validator = Validator::make($allInput, $rules);
    if ($validator->fails()) {
      $errors = $validator->errors();
      return Redirect::to('admin/projects/edit/' . $id)
        ->withErrors($errors)
        ->withInput();
    } else {
      $project = Project::findOrFail($id);
      $project->fill(Input::except(['photos', 'before_photos', 'after_photos', 'image_titles']));
      if (isset($allInput['image_titles'])) {
      	$this->doUpdateImageTitles($allInput['image_titles']);
      }
      $project->save();
      Session::flash('flash', ['message' => 'Successfully updated project.', 'type' => 'flash-success']);
      return Redirect::to('admin/projects/edit/' . $project->id);
    }
  }

  public function doUpdateImageTitles($imageTitles) {
		DB::transaction(function() use ($imageTitles) {
			foreach ($imageTitles as $id => $imageTitle) {
				DB::table('project_images')
					->where('id', $id)
					->update(array('title' => $imageTitle));
			}
		});
  }

  public function newProject() {
    $project = new Project;
    return View::make('admin.editProject')
      ->with('project', $project);
  }

  public function doNewProject() {
    $rules = Project::$rules;
    $allInput = Input::all();
    $validator = Validator::make($allInput, $rules);
    if ($validator->fails()) {
      $errors = $validator->errors();
      return Redirect::route('admin.newProject')
        ->withErrors($errors)
        ->withInput();
    } else {
      $project = Project::create(Input::all());
      Session::flash('flash', ['message' => 'Successfully created project.', 'type' => 'flash-success']);
      return Redirect::to('admin/projects/edit/' . $project->id);
    }
  }

	// Content Blocks
	// -------------------------------

	public function showContent()
	{
		$cbs = ContentBlock::all();
		return View::make('admin.content')
			->with('content_blocks', $cbs);
	}

	public function editContent($id = null)
	{
		if ($id) {
			$cb = ContentBlock::findOrFail($id);
			return View::make('admin.editContent')
				->with('content_block', $cb);
		} else {
			return View::make('admin.newContent')
				->with('content_block', null);
		}
	}

	public function inlineEditContent($id)
	{
		$cb = ContentBlock::findOrFail($id);
		return View::make('admin.inlineEditContent')
			->with('content_block', $cb);
	}

	public function doInlineEditContent($id) {
		$cb = ContentBlock::findOrFail($id);
		$rt = $cb->renderable_type;
		$cbTypeRules = $rt::$rules;

		$validatorCbType = Validator::make(Input::all(), $cbTypeRules);

		if ($validatorCbType->fails()) {
			$errors = $validatorCbType->errors();
			return Redirect::to('admin/content/inline-edit/' . $id)
				->withErrors($errors)
				->withInput(Input::all());
		} else {
			$cb->renderer()->doEditContent();
			$cb->save();

			Session::flash('flash', ['message' => 'Successfully updated content.', 'type' => 'flash-success']);
			return Redirect::to('admin/content/inline-edit/' . $id);
		}
	}

	public function typeFields($type) {
		if(class_exists($type)) {
			$cbt = new $type();
			return $cbt->renderEditFields();
		}
	}

	public function deleteContent($id) {
		$cb = ContentBlock::findOrFail($id);
		$cb->renderer()->delete();
		$cb->delete();
		Session::flash('flash', ['message' => 'Successfully deleted content!', 'type' => 'flash-success']);
		return Redirect::to('admin/content');
	}

	public function copyContent($id) {
		$cb = ContentBlock::findOrFail($id);
		$cb_clone = $cb->replicate();
		$cb_clone->name = $cb_clone->name . "-new";
		$cb_clone->save();
		$cbType_clone = $cb->renderer()->replicate();
		$cbType_clone->content_block()->save($cb_clone);
		$cbType_clone->save();
		$cb_clone->renderable_id = $cbType_clone->id;
		$cb_clone->save();

		Session::flash('flash', ['message' => 'Successfully copied content!', 'type' => 'flash-success']);

		return Redirect::to('admin/content/edit/' . $cb_clone->id);
	}

	public function doEditContent($id) {
		$cb = ContentBlock::findOrFail($id);
		$cbRules = ContentBlock::$rules;
		$rt = $cb->renderable_type;
		$cbTypeRules = $rt::$rules;

		$validatorCb = Validator::make(Input::all(), $cbRules);
		$validatorCbType = Validator::make(Input::all(), $cbTypeRules);

		if ($validatorCb->fails() || $validatorCbType->fails()) {
			$errors = $validatorCb->errors();
			$errors->merge($validatorCbType->errors());
			return Redirect::to('admin/content/edit/' . $id)
				->withErrors($errors)
				->withInput(Input::all());
		} else {
			$cb->name       	 = Input::get('name');
			$cb->description 	 = Input::get('description');
			$cb->renderer()->doEditContent();
			$cb->save();

			Session::flash('flash', ['message' => 'Successfully updated content.', 'type' => 'flash-success']);
			return Redirect::to('admin/content');
		}
	}

	public function doNewContent() {
		$cbRules = ContentBlock::$rules;
		$rt = Input::get('renderable_type');
		$cbTypeRules = $rt::$rules;
		$allInput = Input::all();

		$validatorCb = Validator::make($allInput, $cbRules);
		$validatorCbType = Validator::make($allInput, $cbTypeRules);

		if ($validatorCb->fails() || $validatorCbType->fails()) {
			$errors = $validatorCb->errors();
			$errors->merge($validatorCbType->errors());
			return Redirect::route('admin.newContent')
				->withErrors($errors)
				->withInput();
		} else {
			$cb = ContentBlock::build($rt, $allInput, $allInput);

			Session::flash('flash', ['message' => 'Successfully created content.', 'type' => 'flash-success']);
			return Redirect::to('admin/content/edit/' . $cb->id);
		}
	}

  // Suppliers
  // -------------------------------

  public function showSuppliers()
  {
    $suppliers = Supplier::all();
    return View::make('admin.suppliers')
      ->with('suppliers', $suppliers);
  }

  public function editSupplier($id)
  {
    $supplier = Supplier::findOrFail($id);
    return View::make('admin.editSupplier')
      ->with('supplier', $supplier);
  }

  public function deleteSupplier($id) {
    $obj = Supplier::findOrFail($id);
    $obj->delete();
    Session::flash('flash', ['message' => 'Successfully deleted supplier!', 'type' => 'flash-success']);
    return Redirect::to('admin/suppliers');
  }

  public function doEditSupplier($id) {
    $rules = Supplier::$rules;
    $allInput = Input::all();
    $validator = Validator::make($allInput, $rules);
    if ($validator->fails()) {
      $errors = $validator->errors();
      return Redirect::to('admin/suppliers/edit/' . $id)
        ->withErrors($errors)
        ->withInput();
    } else {
      $supplier = Supplier::findOrFail($id);
      $supplier->fill(Input::all());
      $supplier->save();
      Session::flash('flash', ['message' => 'Successfully updated supplier.', 'type' => 'flash-success']);
      return Redirect::to('admin/suppliers/edit/' . $supplier->id);
    }
  }

  public function newSupplier() {
    $supplier = new Supplier;
    return View::make('admin.editSupplier')
      ->with('supplier', $supplier);
  }

  public function doNewSupplier() {
    $rules = Supplier::$rules;
    $allInput = Input::all();
    $validator = Validator::make($allInput, $rules);
    if ($validator->fails()) {
      $errors = $validator->errors();
      return Redirect::route('admin.newSupplier')
        ->withErrors($errors)
        ->withInput();
    } else {
      $supplier = Supplier::create(Input::all());
      Session::flash('flash', ['message' => 'Successfully created supplier.', 'type' => 'flash-success']);
      return Redirect::to('admin/suppliers/edit/' . $supplier->id);
    }
  }

}
