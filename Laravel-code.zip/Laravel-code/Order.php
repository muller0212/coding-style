<?php namespace App\Model;

use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Eloquent
{
    use SoftDeletes;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'orders';

    /**
     * The relations to eager load on every query.
     *
     * @var array
     */
    protected $with = ['detail'];

    const CANCELLED  = 'cancelled';
    const COMPLETED  = 'paid';
    const FAILED     = 'failed';
    const FREE       = 'free';
    const PAID       = 'paid';
    const PENDING    = 'unpaid';
    const PROCESSING = 'processing';
    const REVOKED    = 'revoked';
    const UNPAID     = 'unpaid';

    /**
     * Has one relationship with OrderDetail.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function detail()
    {
        return $this->hasOne(OrderDetail::class, 'order_id');
    }

    /**
     * Belongs to relationship with User.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Attach order detail to a order.
     *
     * @param  App\Model\OrderDetail  $detail
     *
     * @return $this
     */
    public function addDetail(OrderDetail $detail)
    {
        $this->detail()->save($detail);

        return $this;
    }
}
