(function() {
    'use strict';

    xdescribe('VirtualDeskCtrl', function() {

        var $scope;
        var $rootScope;
        var ctrl;
        var commands;
        var model;
        var controlUnitDummy;

        beforeEach(module('barcelona.ui-common'));
        beforeEach(inject(function(_$rootScope_, _$controller_) {
            $rootScope = _$rootScope_;
            $scope = _$rootScope_.$new();

            model = {};
            controlUnitDummy = {id: 1};

            commands = jasmine.createSpyObj('commands', ['setDeskSignals']);

            ctrl = _$controller_('VirtualDeskCtrl', {
                $scope: $scope,
                $rootScope: $rootScope,
                commands: commands,
                model: model
            });
        }));

        describe('- on -', function() {
            describe('lever', function() {
                it('release', function() {
                    var onChangeSpy = spyOn($scope, 'onChange').and.callThrough();
                    var valueObj = {value: 100};
                    $scope.onRelease(controlUnitDummy, valueObj);
                    expect(onChangeSpy).toHaveBeenCalledWith(controlUnitDummy, 0, false);
                });
                it('change (with 500ms delay from lodash debounce)', function(done) {
                    var value = 100;
                    var approvalPressed = true;
                    $scope.onChange(controlUnitDummy, value, approvalPressed);
                    setTimeout(function() {
                        expect(commands.setDeskSignals).toHaveBeenCalledWith(controlUnitDummy.id,
                            parseFloat(value / 100), approvalPressed, true);
                        done();
                    }, 500);
                });
            });
            describe('button click', function() {
                it('when pressed button status is on', function() {
                    $scope.approvalPressed = true;
                    $scope.pressedButtons = [{controlUnitId: 1, status: 'on'}];
                    $scope.onClick(controlUnitDummy);
                    expect(commands.setDeskSignals).toHaveBeenCalledWith(controlUnitDummy.id, 0, $scope.approvalPressed, true);
                });
                describe('when pressed button status is', function() {
                    beforeEach(function() {
                        $scope.approvalPressed = true;
                    });
                    afterEach(function() {
                        expect(commands.setDeskSignals).toHaveBeenCalledWith(controlUnitDummy.id, 1, $scope.approvalPressed, true);
                    });
                    it('off', function() {
                        $scope.pressedButtons = [{controlUnitId: 1, status: 'off'}];
                        $scope.onClick(controlUnitDummy);
                    });
                    it('undefined', function() {
                        $scope.pressedButtons = [{}];
                        $scope.onClick(controlUnitDummy);
                        expect($scope.pressedButtons[$scope.pressedButtons.length - 1]).toEqual({
                            controlUnitId: controlUnitDummy.id, status: 'on'});
                    });
                });
            });
            describe('approval button', function() {
                it('release', function() {
                    $scope.pressedButtons = [
                        {controlUnitId: 1, status: 'on'},
                        {controlUnitId: 2, status: 'off'}
                    ];
                    $scope.onApprovalRelease();
                    expect(commands.setDeskSignals).toHaveBeenCalledTimes(2);
                    expect($scope.pressedButtons).toEqual([]);
                });
                it('pressed', function() {
                    $scope.onApprovalPressed();
                    expect($scope.approvalPressed).toBeTruthy();
                });
            });
        });

        describe('- handling mouse pointer -', function() {
            describe('can be set', function() {
                it('visible', function() {
                    $rootScope.hidePointer = true;
                    var hidePointer = $rootScope.hidePointer;
                    $scope.togglePointer();
                    expect($rootScope.hidePointer).toEqual(!hidePointer);
                });

                it('invisible', function() {
                    $rootScope.hidePointer = false;
                    var hidePointer = $rootScope.hidePointer;
                    $scope.togglePointer();
                    expect($rootScope.hidePointer).toEqual(!hidePointer);
                });
            });
        });

    });

}());
