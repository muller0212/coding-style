(function() {
    'use strict';

    xdescribe('ShowCtrl ', function() {

        var $rootScope;
        var $scope;
        var $state;
        var ctrl;
        var queries;
        var deferred;
        var commands;
        var $stateParams;
        var dummy;

        beforeEach(module('barcelona.ui-common'));
        beforeEach(module('barcelona.ui-repertoire'));
        beforeEach(inject(function(_$rootScope_, _$controller_, _$q_) {
            $rootScope = _$rootScope_;
            $scope = _$rootScope_.$new();

            // Setup spy for queries service
            queries = jasmine.createSpyObj('queries', ['findShow', 'findPage', 'findObject',
                'findCueByMove', 'findStartDeadForMove', 'findMovesForObjectCreation',
                'showPositionAlert', 'findMachine', 'findSessionAdhocMove']);
            queries.findShow.and.returnValue({id: 1, name: 'DummyShowName'});
            queries.findPage.and.returnValue({id: 1});
            queries.findObject.and.returnValue([{id: 1}]);
            queries.findCueByMove.and.returnValue([{id: 1}]);
            queries.findStartDeadForMove.and.returnValue({name: 'DummyDeadName'});
            queries.findMovesForObjectCreation.and.returnValue([1, 2]);
            queries.showPositionAlert.and.returnValue(true);
            queries.findMachine.and.returnValue({id: 1, name: 'E1'});

            // Set up spy for commands service
            commands = jasmine.createSpyObj('commands', ['updateShow', 'deletePage', 'createPage',
                'createObject', 'createMoveAndAssignObject', 'createMoveAndObject',
                'switchPage', 'movePage', 'reassignMove', 'deactivateCue', 'activateCue', 'reassignCue', 'initiateMoveCreation']);
            deferred = _$q_.defer();
            commands.deletePage.and.returnValue(deferred.promise);
            commands.createPage.and.returnValue(deferred.promise);
            commands.createObject.and.returnValue(deferred.promise);
            commands.createMoveAndAssignObject.and.returnValue(deferred.promise);
            commands.createMoveAndObject.and.returnValue(deferred.promise);
            commands.movePage.and.returnValue(deferred.promise);
            commands.reassignMove.and.returnValue(deferred.promise);
            commands.reassignCue.and.returnValue(deferred.promise);

            $state = jasmine.createSpyObj('state', ['go', 'includes']);
            $state.includes.and.returnValue(true);

            $stateParams = {
                showId: 1,
                pageId: 1,
                cueId: 1
            };

            dummy = {
                cue: {id: 1, controlUnit: 1, moves: []},
                page: {id: 1},
                move: {id: 1, controlUnit: 1, axisParameters: []}
            };

            ctrl = _$controller_('ShowCtrl', {
                $scope: $scope,
                $rootScope: $rootScope,
                $stateParams: $stateParams,
                $state: $state,
                queries: queries,
                commands: commands,
                machinery: {},
                desk: function() {
                    return false;
                }
            });
        }));

        describe('- when loading -', function() {
            it('properly sets the name of show', function() {
                expect(queries.findShow).toHaveBeenCalledWith($stateParams.showId);
                expect($rootScope.headerTitle).toEqual('DummyShowName');
            });

            it('properly sets the active page', function() {
                expect(queries.findPage).toHaveBeenCalledWith($stateParams.pageId);
                expect($scope.activePage.id).toEqual(1);
            });
        });

        xdescribe('- can select -', function() {
            it('a page', function() {
                var pageId = 1;
                $scope.selectPage(pageId);
                expect($scope.activePage).toEqual({id: 1});
                expect($scope.selectedItem).toEqual($scope.activePage);
                expect($scope.selectedRightPanelTab).toEqual('inspector');
                expect($state.go).toHaveBeenCalledWith('repertoire.show.detail', {pageId: pageId});
            });

            it('a cue', function() {
                $scope.selectCue(dummy.page, dummy.cue);
                expect($scope.selectedRightPanelTab).toEqual('inspector');
                expect($scope.selectedItem).toEqual(dummy.cue);
                expect($state.go).toHaveBeenCalledWith('repertoire.show.cue', {
                    pageId: dummy.page.id,
                    cueId: dummy.cue.id
                });
            });

            it('machine parameters', function() {
                var machineParam = {machine: 1};
                $scope.selectMachineParameter(machineParam, dummy.move, dummy.cue);
                expect($scope.selectedItem).toEqual(machineParam);
                expect($scope.selectedRightPanelTab).toEqual('inspector');
                expect($state.go).toHaveBeenCalledWith('repertoire.show.move.axis-parameters', {
                    moveId: dummy.move.id,
                    cueId: dummy.cue.id,
                    selectedMachines: [{machineParam: {machine: 1}}],
                });
            });

            it('a object', function() {
                var objectId = 1;
                $scope.selectShowObjectParameters(objectId);
                expect(queries.findObject).toHaveBeenCalledWith($scope.show, objectId);
                expect($scope.selectedItem).toEqual([{id: 1}]);
                expect($scope.selectedRightPanelTab).toEqual('inspector');
                expect($state.go).toHaveBeenCalledWith('repertoire.show.object', {objectId: objectId});
            });

            it('the right panel tab', function() {
                $scope.selectRightPanelTab('Name');
                expect($scope.selectedRightPanelTab).toEqual('Name');
            });

            it('an move', function() {
                $scope.selectMove(dummy.move, dummy.cue);
                expect($scope.selectedItem).toEqual(dummy.move);
                expect($scope.selectedRightPanelTab).toEqual('inspector');
                expect($state.go).toHaveBeenCalledWith('repertoire.show.move', {
                    cueId: dummy.cue.id,
                    moveId: dummy.move.id
                });
            });

        });

        describe('- can create -', function() {
            it('a page', function() {
                var selectPageSpy = spyOn($scope, 'selectPage').and.callThrough();
                $scope.createPage();
                deferred.resolve({pageId: 1});
                $scope.$apply();
                expect(commands.createPage).toHaveBeenCalled();
                expect(selectPageSpy).toHaveBeenCalled();
            });

            describe('an move by machine', function() {
                it('without cue', function() {
                    dummy.cue = undefined;
                    $scope.createMoveByMachine(dummy.cue);
                    expect(commands.initiateMoveCreation).toHaveBeenCalledWith({
                        showId: $scope.show.id,
                        pageId: $scope.activePage.id
                    });
                });
                it('with cue', function() {
                    $scope.createMoveByMachine(dummy.cue);
                    expect(commands.initiateMoveCreation).toHaveBeenCalledWith({
                        showId: $scope.show.id,
                        pageId: $scope.activePage.id, cueId: dummy.cue.id
                    });
                });
            });

            it('an object by move', function() {
                var selectShowObjectParametersSpy = spyOn($scope, 'selectShowObjectParameters').and.callThrough();
                $scope.createObjectByMove(dummy.move, dummy.cue);
                deferred.resolve({objectId: 1});
                $scope.$apply();
                expect(commands.createObject).toHaveBeenCalledWith($scope.show.id,
                    $stateParams.pageId, dummy.cue.id, [1, 2]);
                expect(selectShowObjectParametersSpy).toHaveBeenCalled();
            });

            it('an move by object', function() {
                var selectShowObjectParametersSpy = spyOn($scope, 'selectShowObjectParameters').and.callThrough();
                $scope.createMoveByObject();
                deferred.resolve({objectId: 1});
                $scope.$apply();
                expect(commands.createMoveAndObject).toHaveBeenCalledWith($stateParams.pageId,
                    $stateParams.cueId);
                expect(selectShowObjectParametersSpy).toHaveBeenCalled();
            });
        });

        describe('- can find - ', function() {
            it('start position dead name', function() {
                var result = $scope.findStartPositionDeadName(dummy.move);
                expect(queries.findStartDeadForMove).toHaveBeenCalledWith($scope.show, $scope.activePage, dummy.move);
                expect(result).toBe('DummyDeadName');
            });
        });

        describe('- can update -', function() {
            it('the name of the show', function() {
                $rootScope.editingTitle = true;
                $scope.editTitle();
                expect(commands.updateShow).toHaveBeenCalledWith($scope.show.id, {name: 'DummyShowName'});
            });
        });

        describe('- does not -', function() {
            it('allow to edit in states where show is not the parent', function() {
                $state.includes.and.returnValue(false);
                $rootScope.editingTitle = false;
                $scope.editTitle();
                expect($rootScope.editingTitle).toBe(false);
                expect(commands.updateShow).not.toHaveBeenCalled();
            });
        });

        describe('- can add -', function() {
            it('machines', function() {
                $scope.addMachines(dummy.move, dummy.cue);
                expect(queries.findCueByMove).toHaveBeenCalledWith($scope.activePage, dummy.move);
                expect(commands.initiateMoveCreation).toHaveBeenCalledWith({
                    showId: $scope.show.id,
                    pageId: $scope.activePage.id, cueId: queries.findCueByMove($scope.activePage, dummy.move).id,
                    moveId: dummy.move.id, controlUnitId: dummy.cue.id
                });
            });
        });

        describe('- can get -', function() {
            it('getting control unit', function() {
                var controlUnitId = 1;
                $scope.session = {
                    desk: {
                        controlUnits: [
                            {id: 1}
                        ]
                    }
                };
                var result = $scope.getControlUnit(controlUnitId);
                expect(result).toEqual({id: 1});
            });
        });

        describe('- can show -', function() {
            describe('position alert', function() {
                it('is shown when page is active', function() {
                    $scope.activePage.id = 1;
                    dummy.cue.positionAlert = true;
                    var result = $scope.showPositionAlert(dummy.page, dummy.cue);
                    expect(result).toBeTruthy();
                });
                it('is not shown when page is not active', function() {
                    $scope.activePage.id = 6;
                    dummy.cue.positionAlert = true;
                    var result = $scope.showPositionAlert(dummy.page, dummy.cue);
                    expect(result).toBeFalsy();
                });
            });
        });

        describe('- handling drag and drop -', function() {
            describe('when dropping an item, ', function() {
                it('requests a dropped page to be moved in the backend and selects the page again', function() {
                    var selectPageSpy = spyOn($scope, 'selectPage').and.callThrough();
                    var obj = {id: 1};
                    var index = {};

                    $scope.onPageDropped(index, obj);
                    deferred.resolve();
                    $scope.$apply();

                    expect(commands.movePage).toHaveBeenCalledWith($scope.show.id, obj.id, index);
                    expect(selectPageSpy).toHaveBeenCalledWith(obj.id);
                });
                it('request a dropped move to be moved on the same field of the same page', function() {
                    var targetControlUnit = {id: 1}; // Same control unit;
                    var targetPage = {id: 1};
                    $scope.activePage.id = targetPage.id; // Same page;
                    $scope.onMoveOrCueDropped(dummy.move, targetControlUnit, targetPage);
                    expect(commands.reassignMove).not.toHaveBeenCalled();
                });
                it('request a dropped move to be moved on the same page', function() {
                    var targetControlUnit = {id: 2}; // Different Control Unit
                    var targetPage = {id: 1};
                    $scope.activePage.id = targetPage.id; // Same page;
                    $scope.onMoveOrCueDropped(dummy.move, targetControlUnit, targetPage);
                    expect(commands.reassignMove).toHaveBeenCalledWith(dummy.move.id, targetControlUnit.id, targetPage.id);
                });
                it('request a dropped move to be moved on an a different page', function() {
                    var targetControlUnit = {id: 1};
                    var targetPage = {id: 2};
                    $scope.activePage.id = 1; // Different page;
                    $scope.onMoveOrCueDropped(dummy.move, targetControlUnit, targetPage);
                    expect(commands.reassignMove).toHaveBeenCalledWith(dummy.move.id, targetControlUnit.id, targetPage.id);
                });
                it('request a dropped move to be moved on another page with the same machines', function() {
                    var errorMessageModalSpy = spyOn(ctrl, 'openErrorDialog').and.callThrough();
                    var targetControlUnit = {id: 1};
                    var targetPage = {
                        id: 2,
                        cues: [
                            {
                                moves: [
                                    {
                                        axisParameters: [
                                            {
                                                machine: 1 // Same machine as move
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    };
                    dummy.move = {
                        axisParameters: [
                            {
                                machine: 1 // Same machine as page
                            }
                        ]
                    };
                    $scope.activePage.id = 1; // Different page;
                    $scope.onMoveOrCueDropped(dummy.move, targetControlUnit, targetPage);
                    expect(commands.reassignMove).not.toHaveBeenCalled();
                    expect(errorMessageModalSpy).toHaveBeenCalled();
                });
                it('request a dropped cue to be moved on the same field of the same page', function() {
                    var targetControlUnit = {id: 1}; // Same control unit;
                    var targetPage = {id: 1};
                    $scope.activePage.id = targetPage.id; // Same page;
                    $scope.onMoveOrCueDropped(dummy.cue, targetControlUnit, targetPage);
                    expect(commands.reassignCue).not.toHaveBeenCalled();
                });
                it('request a dropped cue to be moved on the same page', function() {
                    var targetControlUnit = {id: 2}; // Different Control Unit
                    var targetPage = {id: 1};
                    $scope.activePage.id = targetPage.id; // Same page;
                    $scope.onMoveOrCueDropped(dummy.cue, targetControlUnit, targetPage);
                    expect(commands.reassignCue).toHaveBeenCalledWith(dummy.cue.id, targetControlUnit.id, targetPage.id);
                });
                it('request a dropped cue to be moved on an a different page', function() {
                    var targetControlUnit = {id: 1};
                    var targetPage = {id: 2};
                    $scope.activePage.id = 1; // Different page;
                    $scope.onMoveOrCueDropped(dummy.cue, targetControlUnit, targetPage);
                    expect(commands.reassignCue).toHaveBeenCalledWith(dummy.cue.id, targetControlUnit.id, targetPage.id);
                });
                it('request a dropped cue to be moved on another page with the same machines', function() {
                    var errorMessageModalSpy = spyOn(ctrl, 'openErrorDialog').and.callThrough();
                    var targetControlUnit = {id: 1};
                    var targetPage = {
                        id: 2,
                        cues: [
                            {
                                moves: [
                                    {
                                        axisParameters: [
                                            {
                                                machine: 1 // Same machine as cue.
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    };
                    dummy.cue.moves = [
                        {
                            axisParameters: [
                                {
                                    machine: 1 // Same machine as page
                                }
                            ]
                        }
                    ];
                    $scope.activePage.id = 1; // Different page;
                    $scope.onMoveOrCueDropped(dummy.cue, targetControlUnit, targetPage);
                    expect(commands.reassignCue).not.toHaveBeenCalled();
                    expect(errorMessageModalSpy).toHaveBeenCalled();
                });
            });

        });

        describe('- on cue activation/deactivation clicked -', function() {

            it('requests cue activation', function() {
                var isCueActiveSpy = spyOn($scope, 'isCueActive').and.callThrough();
                isCueActiveSpy.and.returnValue(true);
                $scope.onCueStateClicked(dummy.cue);
                expect(commands.deactivateCue).toHaveBeenCalledWith(dummy.cue.id);
            });

            it('requests cue deactivation', function() {
                var isCueActiveSpy = spyOn($scope, 'isCueActive').and.callThrough();
                isCueActiveSpy.and.returnValue(false);
                $scope.onCueStateClicked(dummy.cue);
                expect(commands.activateCue).toHaveBeenCalledWith(dummy.cue.id);
            });

        });

        xdescribe('- handling pages changes - ', function() {

            describe('deleting a page', function() {
                it('requests page deletion', function() {
                    $scope.show = {id: 1, name: 'DummyName', pages: [{id: 1}, {id: 2}]};
                    $scope.activePage = $scope.show.pages[0];
                    $scope.deletePage();
                    deferred.resolve({pageId: 2});
                    $scope.$apply();
                    expect(commands.deletePage).toHaveBeenCalled();
                    expect($state.go).toHaveBeenCalled();
                });

                it('does not allow to delete the last page', function() {
                    $scope.show = {id: 1, name: 'DummyName', pages: [{id: 1}]};
                    $scope.deletePage();
                    expect(commands.deletePage).not.toHaveBeenCalled();
                });

                it('selects the next page if existing', function() {
                    $scope.show = {id: 1, name: 'DummyName', pages: [{id: 1}, {id: 2}]};
                    $scope.activePage = $scope.show.pages[0];
                    $scope.deletePage();
                    deferred.resolve({pageId: 2}); //When delete newPageId should be 2.
                    $scope.$apply();
                    expect($state.go).toHaveBeenCalledWith('repertoire.show.detail', {showId: 1, pageId: 2});
                });

                it('selects the previous page if next page not existing', function() {
                    $scope.show = {id: 1, name: 'DummyName', pages: [{id: 1}, {id: 2}]};
                    $scope.activePage = $scope.show.pages[1];
                    $scope.deletePage();
                    deferred.resolve({pageId: 1});
                    $scope.$apply();
                    expect($state.go).toHaveBeenCalledWith('repertoire.show.detail', {showId: 1, pageId: 1});
                });
            });

            it('changing page', function() {
                var index = 1;
                $scope.changePage(index);
                expect(queries.findPage).toHaveBeenCalledWith($scope.show, index);
                expect($state.go).toHaveBeenCalledWith('repertoire.show', {pageId: index, showId: $scope.show.id});
            });
        });

    });

}());
