(function() {
    'use strict';

    xdescribe('OverviewCtrl', function() {

        var $rootScope;
        var $scope;
        var ctrl;
        var model;
        var queries;
        var commands;
        var $state;
        var deferred;

        beforeEach(module('barcelona.ui-common'));
        beforeEach(module('barcelona.ui-repertoire'));
        beforeEach(inject(function(_$rootScope_, _$controller_, _$q_) {
            $rootScope = _$rootScope_;
            $scope = _$rootScope_.$new();
            $scope.session = {user: {id: 1, username: 'Tester'}};
            $scope.$parent = _$rootScope_.$new();
            $scope.$parent.$parent = _$rootScope_.$new();

            // Setup mock for model
            model = {
                shows: [
                    {id: 1, name: 'S1', isArchived: false, pages: [{id: 1}]},
                    {id: 2, name: 'S2', isArchived: true, pages: [{id: 1}]}
                ],
                users: [{id: 1, name: 'mschmitt', favoriteShows: [1]}]
            };

            // Setup spy for queries service
            queries = jasmine.createSpyObj('queries', ['findShows', 'findShow']);
            queries.findShows.and.returnValue([]);
            queries.findShow.and.returnValue(model.shows[1]);

            // Set up spy for commands service
            commands = jasmine.createSpyObj('commands', ['removeShowFromFavorites', 'addShowToFavorites',
                'updateShow', 'deleteShow', 'createShow']);
            deferred = _$q_.defer();
            commands.createShow.and.returnValue(deferred.promise);

            // Set up spy for $state service
            $state = jasmine.createSpyObj('state', ['go', 'includes']);
            $state.includes.and.returnValue(false);

            ctrl = _$controller_('OverviewCtrl', {
                $rootScope: $rootScope,
                $scope: $scope,
                model: model,
                queries: queries,
                commands: commands,
                $state: $state
            });
        }));

        describe('- when loading -', function() {
            it('set the title of the header', function() {
                expect($scope.$parent.$parent.headerTitle).toBe('Dashboard');
                expect($scope.allShows).toBeDefined();
            });
        });

        describe('- handling shows - ', function() {
            xit('can remove a favorite show', function() {
                $scope.toggleFavoriteStatus(model.shows[0]);
                expect(commands.removeShowFromFavorites).toHaveBeenCalled();
            });

            xit('can add a favorite show', function() {
                $scope.toggleFavoriteStatus(model.shows[1]);
                expect(commands.addShowToFavorites).toHaveBeenCalled();
            });

            it('can archive a show', function() {
                $scope.toggleArchived(model.shows[0]);
                expect(commands.updateShow).toHaveBeenCalled();
            });

            it('can delete a show', function() {
                $scope.deleteShow(model.shows[0]);
                expect(commands.deleteShow).toHaveBeenCalled();
            });

            it('can select a show', function() {
                var showId = 1;
                $scope.selectShow(showId);
                expect(queries.findShow).toHaveBeenCalledWith(showId);
                expect($state.go).toHaveBeenCalledWith('repertoire.show.detail', {showId: 1, pageId: 1});
            });

            xit('can gets list of favorite shows', function() {
                $scope.getFavoriteShows();
                expect(queries.findShows).toHaveBeenCalled();
            });

            xit('can create a show', function() {
                $scope.createShow(model.shows[0].id);
                deferred.resolve({id: 3});
                $scope.$apply();
                expect(commands.createShow).toHaveBeenCalled();
                expect(queries.findShow).toHaveBeenCalled();
                expect($state.go).toHaveBeenCalled();
            });
        });

        describe('- can filter -', function() {
            it('a show by name', function() {
                $scope.filter = 'S1';
                $scope.hideArchived = false;
                expect($scope.isMatchingFilter($scope.allShows[0])).toBe(true);
                expect($scope.isMatchingFilter($scope.allShows[1])).toBe(false);
            });

            it('by archived shows', function() {
                $scope.filter = '';
                $scope.hideArchived = true;
                expect($scope.isMatchingFilter($scope.allShows[0])).toBe(true);
                expect($scope.isMatchingFilter($scope.allShows[1])).toBe(false);
            });
        });
    });
}());
