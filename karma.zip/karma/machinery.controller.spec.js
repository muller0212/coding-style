(function() {
    'use strict';

    xdescribe('MachineryCtrl ', function() {

        var $rootScope;
        var $scope;
        var machinery;
        var queries;
        var deferred;
        var commands;
        var ctrl;
        var $state;
        var $stateParams;
        var dummyMachine = {id: 1};
        var dummyCU = {id: 10};
        var dummyDead = {name: 'dummyDead'};

        beforeEach(module('barcelona.ui-repertoire'));
        beforeEach(module('barcelona.ui-machinery'));
        beforeEach(inject(function(_$rootScope_, _$window_, _$controller_, _$q_) {
            $rootScope = _$rootScope_;
            $scope = _$rootScope_.$new();

            // Setup spy for queries service
            queries = jasmine.createSpyObj('queries', ['findDeads', 'findShow', 'findPage',
                'findObjectByMachine', 'findMove', 'findCueByMove', 'findObjectByMachine',
                'findMaxSpeedForMachines', 'findMachinesByPage']);
            queries.findDeads.and.returnValue([{id: 1, name: 'dummyDead'}]);
            queries.findShow.and.returnValue({name: 'dummyShow'});
            queries.findPage.and.returnValue({id: 1});
            queries.findMove.and.returnValue({id: 1});
            queries.findCueByMove.and.returnValue({id: 1});
            queries.findObjectByMachine.and.returnValue({id: 1});

            // Set up spy for commands service
            commands = jasmine.createSpyObj('commands', ['createMoveAndAssignDead', 'reassignMove', 'addMachines',
                'selectMachines', 'replaceAxis']);
            deferred = _$q_.defer();
            commands.createMoveAndAssignDead.and.returnValue(deferred.promise);
            commands.addMachines.and.returnValue(deferred.promise);
            commands.replaceAxis.and.returnValue(deferred.promise);

            // Set up spy for $state service
            $state = jasmine.createSpyObj('$state', ['go']);

            // Setup spy for machinery service
            machinery = jasmine.createSpyObj('machinery', ['findMachines', 'allMachines']);
            machinery.findMachines.and.returnValue([{name: 'dummyMachine'}]);
            machinery.allMachines.and.returnValue([{name: 'dummyMachine'}]);

            $stateParams = {
                pageId: 1,
                showId: 1,
                moveId: 1
            };

            ctrl = _$controller_('MachineryCtrl', {
                $scope: $scope,
                $window: _$window_,
                queries: queries,
                machinery: machinery,
                commands: commands,
                $state: $state,
                $stateParams: $stateParams,
            });
        }));

        describe('- handling machines - ', function() {
            it('can select machines', function() {
                $scope.selectedMachines = [];

                $scope.onMachineClicked(dummyMachine);
                expect($scope.selectedMachines).toEqual([dummyMachine.id]);
            });

            it('can deselect machines', function() {
                $scope.show = undefined;
                $scope.selectedMachines = [dummyMachine.id];

                $scope.onMachineClicked(dummyMachine);
                expect($scope.selectedMachines).toEqual([]);
            });
        });

        describe('- handling control units - ', function() {
            it('can select a control unit', function() {
                $scope.selectedControlUnit = undefined;

                $scope.onControlUnitClicked(dummyCU);
                expect($scope.selectedControlUnit).toEqual(dummyCU);
            });

            it('can deselect a control unit', function() {
                $scope.selectedControlUnit = dummyCU;

                $scope.onControlUnitClicked(dummyCU);
                expect($scope.selectedControlUnit).toBeUndefined();
            });
        });

        describe('- handling deads - ', function() {
            it('can find deads', function() {
                var result = $scope.findDeads([dummyMachine]);
                expect(queries.findDeads).toHaveBeenCalledWith($scope.show, [dummyMachine]);
                expect(result).toEqual([{id: 1, name: 'dummyDead'}]);
            });
        });

        describe('- handling click on dead or free run - ', function() {
            describe('with defined show', function() {
                beforeEach(function() {
                    $scope.show = {id: 1};
                });
                it('and defined moveId', function() {
                    var returnToShowSpy = spyOn(ctrl, 'returnToShow');
                    $scope.moveId = undefined;
                    $scope.selectedControlUnit = {id: 1};

                    $scope.onDeadOrFreeRunClicked(dummyDead);
                    deferred.resolve({moveId: 1, cueId: 1});
                    $scope.$apply();

                    expect(queries.findPage).toHaveBeenCalledWith($scope.pageId);
                    expect(commands.createMoveAndAssignDead).toHaveBeenCalled();
                    expect(returnToShowSpy).toHaveBeenCalledWith({moveId: 1, cueId: 1});
                });

                it('and undefined moveId', function() {
                    var returnToShowSpy = spyOn(ctrl, 'returnToShow');
                    $scope.moveId = 1;

                    $scope.onDeadOrFreeRunClicked(dummyDead);
                    deferred.resolve({moveId: 1, cueId: 1});
                    $scope.$apply();

                    expect(queries.findMove).toHaveBeenCalledWith({id: 1}, $scope.moveId);
                    expect(commands.addMachines).toHaveBeenCalled();
                    expect(returnToShowSpy).toHaveBeenCalledWith({moveId: 1, cueId: 1});
                });
            });

            xit('with undefined show', function() {
                var dummy = {
                    selectedControlUnitId: 1,
                    selectedMachinesIds: [1]
                };
                $scope.show = undefined;
                $scope.selectedControlUnit = {id: dummy.selectedControlUnitId};
                $scope.selectedMachines = dummy.selectedMachinesIds;

                $scope.onDeadOrFreeRunClicked(dummyDead);

                expect(commands.selectMachines).toHaveBeenCalledWith(dummy.selectedControlUnitId,
                    dummy.selectedMachinesIds, dummyDead.name);
                expect($scope.selectedMachines).toEqual([]);
                expect($scope.selectedControlUnit).toEqual(undefined);
            });
        });

        describe('- handling shows -', function() {
            xit('can return to show', function() {
                ctrl.returnToShow({moveId: 1, cueId: 1});

                expect($scope.selectedMachines).toEqual([]);
                expect($scope.machineHeight).toEqual('0px');
                expect($scope.selectedControlUnit).toEqual(undefined);
                expect($state.go).toHaveBeenCalledWith('repertoire.show.move', {
                    showId: 1, pageId: 1, moveId: 1,
                    cueId: 1
                });
            });
        });

        describe('- handling click on machine -', function() {
            describe('- in machine replace state', function() {
                xit('replaces a machine that is selectable', function() {
                    var machine = {id: 2};
                    $stateParams.machineId = 1;
                    $scope.onMachineClicked(machine);
                    expect(commands.replaceAxis).toHaveBeenCalledWith(parseInt($stateParams.moveId), parseInt($stateParams.machineId), machine.id);
                    // ToDo Reactivate this
                    //expect($state.go).toHaveBeenCalledWith('repertoire.show.move.axis-parameters', {
                    //    showId: $stateParams.showId, pageId: $stateParams.pageId,
                    //    moveId: $stateParams.moveId, cueId: $stateParams.cueId, machineId: machine.id
                    //});
                });
                xit('does not replaces a machine that is not selectable', function() {
                    var machine = {id: 2};
                    $stateParams.machineId = 1;
                    $scope.noneSelectableMachines = [1, 2];
                    $scope.onMachineClicked(machine);
                    expect(commands.replaceAxis).not.toHaveBeenCalledWith(parseInt($stateParams.moveId), parseInt($stateParams.machineId), machine.id);
                });
            });
            describe('- in add and create state', function() {
                it('selects a machine that is selectable', function() {
                    var machine = {id: 2};
                    $scope.onMachineClicked(machine);
                    expect($scope.selectedMachines).toEqual([2]);
                });
                it('does not select a machine that is not selectable', function() {
                    var machine = {id: 2};
                    $scope.noneSelectableMachines = [1, 2];
                    $scope.onMachineClicked(machine);
                    expect($scope.selectedMachines).toEqual([]);
                });
            });
        });

    });

}());
